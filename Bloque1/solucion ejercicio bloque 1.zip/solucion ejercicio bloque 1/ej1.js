'use strict';

/**
 * Apartado 1
 * Crea una función que reciba 2 cadenas por parámetro. Dicha función imprimirá por consola qué cadena
 * tiene mayor longitud. Si el tipo de algún parámetro no es string (typeof param !== "string"),
 * debes imprimir un error.
 * Llama a la función 3 veces con diferentes parámetros. En una de esas llamadas pásale por parámetro un valor que no sea string.
 */

console.log('--------------- APARTADO 1 -----------------');

function comparaCad(cad1, cad2) {
    if(typeof cad1 !== "string" || typeof cad2 !== "string") {
        console.error("Los parámetros deben ser de tipo cadena");
        return;
    }

    var l1 = cad1.length, l2 = cad2.length;

    if(l1 > l2) console.log("La cadena '" + cad1 + "' es mayor que '" + cad2 + "'");
    else if(l2 > l1) console.log("La cadena '" + cad2 + "' es mayor que '" + cad1 + "'");
    else console.log("Las cadenas '" + cad1 + "' y '" + cad2 + "' son iguales");
}

comparaCad("hola", "adios");
comparaCad("cacao", "adios");
comparaCad("armario", "adios");
comparaCad(13, "adios");

/**
 * Apartado 2
 * Crea un array con diferentes tipos de valores (números, strings, booleanos). A partir de dicho array,
 * recórrelo y genera otro array con dichos valores convertidos todos a número. Los que no hayan podido
 * ser convertidos (NaN) no deberían estar en el array final. Imprime dicho array resultante por consola.
 */

console.log('--------------- APARTADO 2 -----------------');

var ar = [14, "Pepe", true, null, 3.14, "54", "mmmm"];
var ar2 = [];

ar.forEach(elem => {
    var num = Number(elem);
    if(!isNaN(num)) {
        ar2.push(num);
    }
});

console.log(`Resultado números: ${ar2}`);

/**
 * Apartado 3
 * Haz lo mismo que en el apartado anterior pero usando los métodos nuevos de EcmaScript 5 (map, filter, ...)
 * Pista: Deberías primero generar un array con todos los valores convertidos a número (map), y a partir de
 * este generar otro array filtrando los que no son NaN (filter). Con el array resultante, utiliza el método
 * reduce para sumarlos.
 */

console.log('--------------- APARTADO 3 -----------------');

var ar = [14, "Pepe", true, null, 3.4, "54", "mmmm"];
var suma = ar.map(elem => Number(elem))
    .filter(num => !isNaN(num))
    .reduce((total, num) => total + num);

console.log(`Suma números: ${ar2}`);

/**
 * Apartado 4
 * Crea una función que reciba 3 parámetros (nombre de producto, precio e impuesto en porcentaje sobre 100).
 * Dicha función hará lo siguiente:
 * - Los parámetros deberán tener un valor por defecto por si no los recibe que deben ser: "Producto genérico", 100 y 21.
 * - Convierte el nombre de producto a string (por si acaso) y los otros 2 a número. Si el precio o el impuesto no son
 *   numéros válidos muestra un error. Si son válidos, muestra por consola el nombre del producto y el precio final contando impuestos.
 * - Llama a la función varias veces, omitiendo parámetros, con todos ellos, y pasándo algún valor no númerico en el precio o impuesto.
 */

console.log('--------------- APARTADO 4 -----------------');

function calculaPrecio(nombre = "Producto genérico", pre = 100, imp = 21) {
    let precio   = +pre;
    let impuesto = +imp;

    if(isNaN(precio) || isNaN(impuesto)) {
        console.error("El precio y el impuesto deben ser numéricos");
    } else {
        console.log(`Precio total de '${nombre}': ${(precio*impuesto/100).toFixed(2)}€`);
    }
}

calculaPrecio();
calculaPrecio("Silla", 76);
calculaPrecio("Altavoz", 40, 15);
calculaPrecio("Nada", "sadf", "dasf");

/**
 * Apartado 5
 * Realiza los siguientes pasos (muestra por consola el resultado después de aplicar cada uno):
 * - Crea un array con 4 elementos
 * - Concatena 2 elementos más al final y 2 al principio
 * - Elimina las posiciones de la 3 a la 5 (incluida)
 * - Inserta 2 elementos más entre el penúltimo y el último
 * - Muestra el array del paso anterior, pero con los elementos separados por "==>"
 */

console.log('--------------- APARTADO 5 -----------------');

var a = [10, 20, 30, 40];
console.log(a.join());

a.unshift(0, 5); // Al principio
a.push(50, 60); // Al final
console.log(a.join());

a.splice(3, 3); // Borramos 3,4,5
console.log(a.join());

a.splice(a.length - 1, 0, 55, 56); // Insertamos 2 elementos antes del último
console.log(a.join());

console.log(a.join(' ==> '));

/**
 * Apartado 6
 * Crea una función que reciba 2 parámetros. El primero será el nombre de una persona,
 * y el segundo serán los trabajos que ha realizado esa persona (usa spread para agruparlos en un array).
 * Posible llamada -> printTrabajos("Pepe", "Albañil", "Programador", "Buscador de tesoros")
 * La función simplemente mostrará por consola el nombre y los trabajos recorriéndolos con un for..of
 */

console.log('--------------- APARTADO 6 -----------------');

function printTrabajos(nombre, ...trabajos) {
    console.log(`Nombre: ${nombre}`);
    for(let trabajo of trabajos) {
        console.log('\t' + trabajo);
    }
}

printTrabajos('Ana', 'Actríz', 'Pregonera', 'Escritora');
printTrabajos('Julio', 'Hombre cartel', 'Broker', 'Desactivador de minas');

/**
 * Apartado 7
 * A partir del siguiente array que contiene productos con mensajes sobre los mismos,
 * filtra los mensajes que empiecen por ERROR (usa el método startsWith).
 * Después recórrelos y mételos en un objeto Map cuya clave sea el nombre del producto
 * y cuyo valor sea un array con los mensajes de error asociados al producto.
 * Recorre el objeto Map mostrando, para cada producto, que errores tiene asociados.
 */

console.log('--------------- APARTADO 7 -----------------');

let mensajes = [
    ['Silla', 'ERROR: Stock no coincide'],
    ['Mesa', 'Pedido de 2 unidades'],
    ['Silla', 'ERROR: El precio no puede ser menor a 1'],
    ['Mesa', 'ERROR: No se pueden enviar 0 unidades'],
    ['Cama', 'ERROR: El fabricante no tiene ese modelo'],
    ['Silla', 'Se ha borrado el producto de la base de datos']
];

let errorMap = new Map();

mensajes.filter(m => m[1].startsWith("ERROR"))
        .forEach(([producto, mensaje]) => {
            if(!errorMap.has(producto))
                errorMap.set(producto, [mensaje]);
            else
                errorMap.get(producto).push(mensaje);
        });
        
errorMap.forEach((mensajes, prod) => console.log(`${prod} tiene los siguientes errores:\n\t${mensajes.join("\n\t")}`));
