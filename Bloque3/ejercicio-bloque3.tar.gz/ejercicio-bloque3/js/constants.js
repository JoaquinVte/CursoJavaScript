'use strict';

const SERVER = 'http://arturober.com/exercise3';
const IMG = SERVER + '/img';