'use strict';

const SERVER = 'http://arturober.com/exercise3';
const IMG_URL = `${SERVER}/img`;