<?php

use Phalcon\Mvc\Micro\Collection as MicroCollection;

$events = new MicroCollection();

$events->setHandler(new EventsController());
$events->setPrefix('/events');

$events->get('/', 'getEvents');
$events->post('/', 'addEvent');
$events->delete('/{id:[0-9]+}', 'deleteEvent');

$app->mount($events); 

/**
 * Not found handler
 */
$app->notFound(function () use ($app) {
    $app->response->setStatusCode(404, "Not Found")->sendHeaders();
    echo json_encode(['ok' => false, 'error' => 'Servicio no encontrado']);
});