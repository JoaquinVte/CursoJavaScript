<?php

class EventsController extends BaseController {

    public function getEvents() {
        return $this->sendOk(['events' => Event::find()]);
    }
    
    public function deleteEvent($id) {
        $event = Event::findFirst('id = ' . $id);

        if (!$event) { // No se ha encontrado
            return $this->sendError('Event not found');
        }

        if ($event->delete()) {
            return $this->sendOk();
        } else {
            return $this->sendError('Error deleting the product!');
        }
    }
    
    public function addEvent() {
        $data = $this->request->getJsonRawBody();
        
        $event = new Event();
        $event->setName($data->name);
        $event->setPrice(floatval($data->price));
        $event->setDescription($data->description);
        $event->setDate($data->date);
        
        $name = sha1(microtime()) . '.jpg';
        $dir = substr($name, 0, 3);
        $photoName = substr($name, 3);
        $path = __DIR__ . '/../../public/img/' . $dir;
        
        if($this->imageUtils->savePhoto($data->image, $path, $photoName, true)) {
            $event->setImage($dir . "/" . $photoName);
        } else {
            return $this->sendError("Image couldn't be saved");
        }
        
        if($event->create()) {
            return $this->sendOk(['event' => $event]);
        } else {
            return $this->sendError("Event couldn't be created.");
        }
    }

}
