'use strict';

/**
 * Apartado 1
 */
console.log("------------ APARTADO 1 --------------");

function comparaCad(cad1, cad2) {
    if(typeof cad1 !== "string" || typeof cad2 !== "string") {
        console.error("Los parámetros deben ser de tipo cadena");
        return;
    }

    var l1 = cad1.length, l2 = cad2.length;

    if(l1 > l2) console.log("La cadena '" + cad1 + "' es mayor que '" + cad2 + "'");
    else if(l2 > l1) console.log("La cadena '" + cad2 + "' es mayor que '" + cad1 + "'");
    else console.log("Las cadenas '" + cad1 + "' y '" + cad2 + "' son iguales");
}

comparaCad("hola", "adios");
comparaCad("cacao", "adios");
comparaCad("armario", "adios");
comparaCad(13, "adios");

/**
 * Apartado 2
 */
console.log("------------ APARTADO 2 --------------");

var ar = [14, "Pepe", true, null, 3.14, "54", "mmmm"];
var ar2 = [];

ar.forEach(function(elem) {
    var num = Number(elem);
    if(!isNaN(num)) {
        ar2.push(num);
    }
});

console.log("Resultado números: " + ar2);

/**
 * Apartado 3
 */
console.log("------------ APARTADO 3 --------------");

var ar = [14, "Pepe", true, null, 3.4, "54", "mmmm"];
var ar2 = ar.map(function(elem) {
        return Number(elem);
    }).filter(function(num) {
        return !isNaN(num);
    });

console.log("Resultado números (ES2015): " + ar2);

/**
 * Apartado 4
 */
console.log("------------ APARTADO 4 --------------");

function calculaPrecio(nom, pre, imp) {
    var nombre   = String(nom || "Producto genérico");
    var precio   = Number(pre || 100);
    var impuesto = Number(imp || 21);

    if(isNaN(precio) || isNaN(impuesto)) {
        console.error("El precio y el impuesto deben ser numéricos");
    } else {
        console.log("Precio total de '" + nombre + "': " + (precio*impuesto/100).toFixed(2) + "€");
    }
}

calculaPrecio();
calculaPrecio("Silla", 76);
calculaPrecio("Altavoz", 40, 15);
calculaPrecio("Nada", "sadf", "dasf");

/**
 * Apartado 5
 */
console.log("------------ APARTADO 5 --------------");

var a = [10, 20, 30, 40];
console.log(a.join());

a.unshift(0, 5); // Al principio
a.push(50, 60); // Al final
console.log(a.join());

a.splice(3, 3); // Borramos 3,4,5
console.log(a.join());

a.splice(a.length - 1, 0, 55, 56); // Insertamos 2 elementos antes del último
console.log(a.join());

console.log(a.join(' ==> '));
