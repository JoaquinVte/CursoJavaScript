"use strict";

let newEventForm = null;

function testInputExpr(input, expr) {
    input.classList.remove("is-valid", "is-invalid");
    if (expr.test(input.value)) {
        input.classList.add("is-valid");
        return true;
    } else {
        input.classList.add("is-invalid");
        return false;
    }
}

function validatePrice() {
    return testInputExpr(document.getElementById("price"),
        /[0-9]+(\.[0-9]{1,2})?/);
}

function validateName() {
    return testInputExpr(document.getElementById("name"),
        /[a-z][a-z ]*/);
}

function validateDescription() {
    return testInputExpr(document.getElementById("description"),
        /.*\S.*/);
}

function validateDate() {
    return testInputExpr(document.getElementById("date"), 
                         /\d{4}-\d{2}-\d{2}/);
}

function validateImage() {
    let imgInput = document.getElementById("image");

    imgInput.classList.remove("is-valid", "is-invalid");
    if(imgInput.files.length > 0) {
        imgInput.classList.add("is-valid");
        return true;
    } else {
        imgInput.classList.add("is-invalid");
        return false;
    }
}

function validateForm(event) {
    event.preventDefault();
    let name = newEventForm.name.value;
    let image = document.getElementById("imgPreview").src;
    let date = newEventForm.date.value;
    let desc = newEventForm.description.value;
    let price = newEventForm.price.value;
    
    let ok = validateName();
    ok = validateDate() && ok;
    ok = validateDescription() && ok;
    ok = validatePrice() && ok;
    ok = validateImage() && ok;

    if (ok) {
        addEvent(name, image, date, desc, price);
        newEventForm.reset();
        document.getElementById("imgPreview").src = "";
        document.querySelectorAll(".form-control").forEach(
            input => input.classList.remove("is-valid", "is-invalid")
        );
    }
}

function loadImage(event) {
    let file = event.target.files[0];
    let reader = new FileReader();

    if (file) reader.readAsDataURL(file);

    reader.addEventListener('load', e => {
        document.getElementById("imgPreview").src = reader.result;
    });
}

function addEvent(name, image, date, desc, price) {
    let deck = document.querySelector(".card-deck:last-of-type");
    console.log(deck);
    if (!deck || deck.children.length === 2) {
        deck = document.createElement("div");
        deck.classList.add("card-deck");
        deck.classList.add("mb-4");
        document.getElementById("eventsContainer").appendChild(deck);
    }

    let card = document.createElement("div");
    card.classList.add("card");
    deck.appendChild(card);

    let img = document.createElement("img");
    img.classList.add("card-img-top");
    img.src = image;
    card.appendChild(img);

    let cardBody = document.createElement("div");
    cardBody.classList.add("card-body");
    card.appendChild(cardBody);

    let cardTitle = document.createElement("h4");
    cardTitle.classList.add("card-title");
    cardTitle.textContent = name;
    cardBody.appendChild(cardTitle);

    let cardText = document.createElement("p");
    cardText.classList.add("card-text");
    cardText.innerText = desc;
    cardBody.appendChild(cardText);

    let cardFooter = document.createElement("div");
    cardFooter.classList.add("card-footer");
    card.appendChild(cardFooter);

    let dateObj = new Date(date);

    let footerText = document.createElement("small");
    footerText.classList.add("text-muted");
    footerText.textContent = `${dateObj.getDate()}/${dateObj.getMonth()}/${dateObj.getFullYear()}`;
    cardFooter.appendChild(footerText);

    let priceText = document.createElement("span");
    priceText.classList.add("float-right");
    priceText.textContent = (+price).toFixed(2) + "€";
    footerText.appendChild(priceText);

}

window.addEventListener("load", e => {
    newEventForm = document.getElementById("newEvent");

    newEventForm.image.addEventListener('change', loadImage); // Cargar imagen

    newEventForm.addEventListener('submit', validateForm); // Enviar formulario
});

