"use strict";
//# sourceMappingURL=ishape.js.map