"use strict";
exports.PI = Math.PI;
//# sourceMappingURL=constants.js.map