export const PI = Math.PI;
