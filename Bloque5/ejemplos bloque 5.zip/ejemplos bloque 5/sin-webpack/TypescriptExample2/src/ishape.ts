export interface IShape {
    getArea(): number;
}