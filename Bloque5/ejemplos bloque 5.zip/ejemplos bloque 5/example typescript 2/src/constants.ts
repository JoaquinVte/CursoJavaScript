export const SERVER = 'http://arturober.com/exercise3';
export const IMG_URL = `${SERVER}/img`;