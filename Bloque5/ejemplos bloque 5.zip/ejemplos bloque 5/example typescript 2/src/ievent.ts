export interface IEvent {
    name: string,
    description: string,
    price: number,
    date: string
}