export interface IEvent {
    id?: number, // Opcional, hasta que no se inserta, no existe
    name: string,
    date: string | Date, // Puede estar como string o Date
    description: string,
    image: string,
    price: number,
    lat: number,
    lng: number,
    distance?: number // Opcional, distancia del evento a tu posición
}
