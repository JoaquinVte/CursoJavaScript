import { EventItem } from "./event.class";
import { Geolocation } from "./geolocation.class";

'use strict';

let newEventForm: HTMLFormElement = null;

function testInputExpr(input: HTMLInputElement, expr: RegExp): boolean {
    input.classList.remove("is-valid", "is-invalid");
    if (expr.test(input.value)) {
        input.classList.add("is-valid");
        return true;
    } else {
        input.classList.add("is-invalid");
        return false;
    }
}

function validatePrice(): boolean {
    return testInputExpr(<HTMLInputElement>document.getElementById("price"),
        /[0-9]+(\.[0-9]{1,2})?/);
}

function validateName(): boolean {
    return testInputExpr(<HTMLInputElement>document.getElementById("name"),
        /[a-z][a-z ]*/);
}

function validateDescription(): boolean {
    return testInputExpr(<HTMLInputElement>document.getElementById("description"),
        /.*\S.*/);
}

function validateDate(): boolean {
    return testInputExpr(<HTMLInputElement>document.getElementById("date"), 
                         /\d{4}-\d{2}-\d{2}/);
}

function validateImage(): boolean {
    let imgInput = document.getElementById("image");

    imgInput.classList.remove("is-valid", "is-invalid");
    if((<HTMLInputElement>imgInput).files.length > 0) {
        imgInput.classList.add("is-valid");
        return true;
    } else {
        imgInput.classList.add("is-invalid");
        return false;
    }
}

function validateForm(event): void {
    event.preventDefault();
    let name = (<HTMLInputElement>document.getElementById("name")).value;
    let image = (<HTMLImageElement>document.getElementById("imgPreview")).src;
    let date = newEventForm.date.value;
    let desc = newEventForm.description.value;
    let price = newEventForm.price.value;

    let ok = validateName();
    ok = validateDate() && ok;
    ok = validateDescription() && ok;
    ok = validatePrice() && ok;
    ok = validateImage() && ok;

    if (ok) {
        Geolocation.getLocation().then(pos => {
            let newEvent = new EventItem({
                name, 
                image, 
                date, 
                description: 
                desc, 
                price, 
                lat: pos.coords.latitude, 
                lng: pos.coords.longitude
            });
            return newEvent.post(); // Podemos devolver otra promesa
        }).then((event => { // Aquí obtenemos el resultado de llamar a post()
            location.assign("index.html");
        })).catch(error => {
            alert(error);
        });
    }
}

function loadImage(event: Event): void {
    let file = (<HTMLInputElement>event.target).files[0];
    let reader = new FileReader();

    if (file) reader.readAsDataURL(file);

    reader.addEventListener('load', e => {
        (<HTMLImageElement>document.getElementById("imgPreview")).src = reader.result;
    });
}

window.addEventListener("load", e => {
    newEventForm = <HTMLFormElement>document.getElementById("newEvent");

    newEventForm.image.addEventListener('change', loadImage);

    newEventForm.addEventListener('submit', validateForm);
});