import { IEvent } from './ievent';

export interface IResponse {
    ok: boolean,
    error?: string,
    event?: IEvent,
    events?: IEvent[],
}

