'use strict';

const SERVER = 'http://arturober.com/bloque5';
const IMG_URL = `${SERVER}/img`;

export {SERVER, IMG_URL};