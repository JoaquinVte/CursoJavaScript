import {SERVER, IMG_URL} from './constants';
import {Http} from './http.class';
import { IEvent } from './ievent';
declare function require(module: string): any; // Ahora podemos usar require
let eventTemplate = require('../templates/event.handlebars');

export class EventItem implements IEvent {
    id?: number;
    name: string;
    date: Date;
    description: string;
    image: string;
    price: number;
    lat: number;
    lng: number;
    distance?: number;

    constructor({id = -1, name, date, description, image, price, lat, lng, distance}: IEvent) {
        this.id          = id;
        this.name        = name;
        this.date        = new Date(date);
        this.description = description;
        this.image       = `${IMG_URL}/${image}`;
        this.price       = +price;
        this.lat         = lat;
        this.lng         = lng;
        this.distance    = distance;
    }

    static getEvents(lat: number, lng: number): Promise<EventItem[]> { // Returns Promise<Array<EventItem>> with the array of EventItems
        return Http.ajax('GET', `${SERVER}/events/${lat}/${lng}`)
            .then((response) => response.events.map(e => new EventItem(e)));
    }

    post(): Promise<EventItem>  { 
        return Http.ajax('POST', `${SERVER}/events`, this)
            .then((response) => {
                if(response.ok) {
                    this.id = response.event.id;
                    this.image = `${IMG_URL}/${response.event.image}`;
                    return new EventItem(response.event);
                } else
                    throw response.error;  
            });
    }

    delete(): Promise<boolean> { 
        return Http.ajax('DELETE', `${SERVER}/events/${this.id}`, this)
        .then((response) => {
            if(response.ok)
                return true;
            else
                throw response.error;  
        });
    }

    toHTML() {
        let card = document.createElement("div");
        card.classList.add("card");
        let date = new Date(this.date);

        card.innerHTML = eventTemplate({
            name: this.name,
            date: `${date.getDate()}/${date.getMonth()}/${date.getFullYear()}`,
            price: this.price.toFixed(2),
            description: this.description,
            image: this.image,
            distance: this.distance.toFixed(2)
        });

        return card;
    }
}
