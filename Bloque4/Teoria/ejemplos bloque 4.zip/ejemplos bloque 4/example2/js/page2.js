import {Person} from './person.class.js';

new Person("John", 34);