"use strict";

console.log("Page 2!");
console.log("Another Page 2!");
console.log("AND another Page 2!");
let a = 5;
console.log(a);
