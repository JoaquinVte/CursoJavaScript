"strict mode";

function print() {
    let num = 34;
    return num * 2;
}
console.log("Index.HTML!");
print();

