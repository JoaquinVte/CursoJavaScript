'use strict';

export const SERVER = 'http://arturober.com/exercise3';
export const IMG = SERVER + '/img';